

    var $body = $('body');
    var  linkToForm = '.toForm'
 

    var rellax = new Rellax('.rellax', {
        breakpoints: [576, 768, 1440]
    });


    $body
        .on('click', linkToForm, function (e) {
            e.preventDefault();
            var id = $(this).attr('href'),
                target = $(id).offset().top;
            $body.add('html').animate({scrollTop: target}, 1200);
        });

 

        

 var flag = 0;
    if ($(window).width() <= 991 && flag === 0) {
        flag = 1; 
        $('.reviews__list,.faq__list,.composition__list').slick({
            dots: true,
            arrows: false, 
            mobileFirst: true,
             fade:true
        }); 
    };
    $(window).on('resize', function (event) {
        if ($(window).width() <= 991 && flag === 0) {
            flag = 1; 
            $('.reviews__list,.faq__list,.composition__list').slick({
                dots: true,
                arrows: false, 
                mobileFirst: true,
                fade:true
            }); 
        }
        else if ($(window).width() > 991 && flag === 1) {
            flag = 0;
            $('.reviews__list,.faq__list,.composition__list').slick('unslick'); 
        }
    });
 


